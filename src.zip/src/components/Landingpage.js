import React from "react";
import Footer from "./Footer";

const Landingpage = () => {
  const containerStyle = {
    display: 'flex',
    flexDirection: 'column',
    minHeight: '90vh',
  };

  const backgroundImageStyle = {
    backgroundImage: `url('https://png.pngtree.com/thumb_back/fh260/back_our/20190622/ourmid/pngtree-music-and-landscape-poster-background-image_210419.jpg')`,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    flexGrow: 1, // Allow the background to grow and fill the remaining space
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  };

  const textContainerStyle = {
    width: '80%',
    maxWidth: '600px',
    textAlign: 'left',
    paddingLeft: '20px',
  };

  return (
    <div style={containerStyle}>
      <div style={backgroundImageStyle}>
        <div className="text-container" style={textContainerStyle}>
          <p className="1h-1">
            People nowadays want music for many reasons because it brings joy,
            expresses emotions, and creates a connection.
          </p>
          <p className="1h-1">
            Music is a way to touch our souls and allows us to relax, energize
            ourselves, or simply be a source of entertainment.
          </p>
          <p className="1h-1">
            Design an application that eases the process of listening to your
            favorite music list in just one click.
          </p>
        </div>
      </div>
      <Footer showFooter={true} />
    </div>
  );
};

export default Landingpage;
