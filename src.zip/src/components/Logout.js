import React from 'react';
import { Nav, Navbar } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

const Logout = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    // Perform any logout actions here

    // Redirect to the login page
    navigate('/login');
  };

  return (
    <Navbar bg="light" expand="lg">
      <Nav.Link onClick={handleLogout}>Logout</Nav.Link>
    </Navbar>
  );
};

export default Logout;