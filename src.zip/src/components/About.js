import React from "react";
const About=()=>{
    return(
        <div>
            About Grooveix
        </div>
    )
}
export default About;