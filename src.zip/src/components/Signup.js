// import { useState } from "react"
// import axios from "axios";
// import { useNavigate } from "react-router-dom"
// import Footer from "./Footer";
 
// export default function SignUp() {
//     const navigate=useNavigate();
//     const [userId,setUserId] = useState();
//     const [username,setUserName] = useState();
//     const [email,setEmail] = useState();
//     const [password,setPassword] = useState();
 
//     const submitForm = async () => {
//         if (!userId || !username || !email || !password) {
//             alert("Please fill in all the fields.");
//             return;
//           }
//         //Make api call
//         try {
//             const response = await axios.post("http://localhost:8083/Grooveix/UserProfile/register",{
//                 userId,
//                 username,
//                 email,
//                 password,
//             });
//             alert("Register Successfully")
//             console.log("Registration Sucessfull",response.data);
//             navigate("/login");
//         } catch(error){
//             console.error("Registration failed", error.message);
//         }
       
//     }
 
//     return(
//         <div className="row justify-content-center pt-3">
//             <div className="col-sm-6">
//                 <div className="card p-4">
//                     <h1 className="text-center mb-3">Register </h1>
//                     <div className="form-group">
//                         <label>userId:</label>
//                         <input type="test" className="form-control" placeholder="Enter userId"
//                             onChange={e=>setUserId(e.target.value)}
//                         id="userId" />
//                     </div>
//                     <div className="form-group">
//                         <label>username:</label>
//                         <input type="test" className="form-control" placeholder="Enter username"
//                             onChange={e=>setUserName(e.target.value)}
//                         id="username" />
//                     </div>
//                     <div className="form-group mt-3">
//                         <label>Email:</label>
//                         <input type="email" className="form-control" placeholder="Enter email"
//                             onChange={e=>setEmail(e.target.value)}
//                         id="email" />
//                     </div>
 
//                     <div className="form-group mt-3">
//                         <label>Password:</label>
//                         <input type="password" className="form-control" placeholder="Enter password"
//                             onChange={e => setPassword(e.target.value)}
//                         id="pwd" />
//                     </div>
//                     <button type="button" onClick={submitForm} className="btn btn-primary mt-4">Register</button>
//                 </div>
//             </div>
//             <Footer showFooter={true} />
//         </div>
//     )
// }

import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import Footer from "./Footer";

export default function SignUp() {
  const navigate = useNavigate();
  const [userId, setUserId] = useState("");
  const [username, setUserName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const submitForm = async () => {
    if (!userId || !username || !email || !password) {
      alert("Please fill in all the fields.");
      return;
    }

    // Validate username format (for example, at least 3 characters)
    if (username.length < 4) {
      alert("Username must be at least 4 characters long.");
      return;
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      alert("Invalid email format.");
      return;
    }

    // Validate password strength (for example, at least 6 characters)
    if (password.length < 4) {
      alert("Password must be at least 6 characters long.");
      return;
    }

    // Make API call
    try {
      const response = await axios.post(
        "http://localhost:8083/Grooveix/UserProfile/register",
        {
          userId,
          username,
          email,
          password,
        }
      );
      alert("Registration Successful");
      console.log("Registration Successful", response.data);
      navigate("/login");
    } catch (error) {
      console.error("Registration failed", error.message);
    }
  };

  return (
    <div className="row justify-content-center pt-3">
      <div className="col-sm-6">
        <div className="card p-4">
          <h1 className="text-center mb-3">Register </h1>
          <div className="form-group">
            <label>userId:</label>
            <input
              type="text"
              className="form-control"
              placeholder="Enter userId"
              onChange={(e) => setUserId(e.target.value)}
              id="userId"
            />
          </div>
          <div className="form-group">
            <label>username:</label>
            <input
              type="text"
              className="form-control"
              placeholder="Enter username"
              onChange={(e) => setUserName(e.target.value)}
              id="username"
            />
          </div>
          <div className="form-group mt-3">
            <label>Email:</label>
            <input
              type="email"
              className="form-control"
              placeholder="Enter email"
              onChange={(e) => setEmail(e.target.value)}
              id="email"
            />
          </div>

          <div className="form-group mt-3">
            <label>Password:</label>
            <input
              type="password"
              className="form-control"
              placeholder="Enter password"
              onChange={(e) => setPassword(e.target.value)}
              id="pwd"
            />
          </div>
          <button
            type="button"
            onClick={submitForm}
            className="btn btn-primary mt-4"
          >
            Register
          </button>
        </div>
      </div>
      <Footer showFooter={true} />
    </div>
  );
}
