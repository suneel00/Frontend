import React,{useState} from 'react';

export default function Song({songName,image,artistName,albumName,releaseDate}){
const imageKeys=Object.keys(image);
const [showDetails, setShowDetails] = useState(false);
const cardStyle = {
    width: '100px',
    height: '250px',
  };
  const songNameStyle = {
    fontSize: '12px', // Set your desired font size
    // fontWeight: 'bold', // Optionally set other styles
  };

//   //wishlist
//   const handleAddToWishlist = () => {
//     // Call the addToWishlist function with the songName as an argument
//     addToWishlist(songName);
//   };

return(
    
    <div className="card-group"style={{maxWidth:"100%"}}>
      <div className="card" style={cardStyle}>  
        {imageKeys.length > 0 && (
          <img
            className="card-img-top"
            src={image[imageKeys[0]].url} 
            alt={`${songName} - card image`}
            style={{ maxWidth: '100%',height:"50%"}}
          />
        )}
        <div className="card-body text-center" style={{height: '50%'}} >
          <h5 className="card-title" style={songNameStyle}>{songName}</h5>
          <p className="card-text"style={songNameStyle}>
          {showDetails ? (
            <>
            {artistName}-{releaseDate}-{albumName} 
            </>
            ) : (
              // Display a truncated version of the content
              `${artistName}-${releaseDate}`
            )}

          </p>
          {/* Toggle button for "read more" */}
          <button
            className="btn btn-link"
            onClick={() => setShowDetails(!showDetails)}
          >
            {showDetails ? 'Read less' : 'Read more'}
          </button>

          {/* wishlist
          <button className="btn btn-primary" onClick={handleAddToWishlist}>
            Add to Wishlist
          </button> */}

          {/* <div className="card-footer text-center"> */}

          <a href="#" className="btn btn-primary" style={{ fontSize: '12px' }}>
            Add to Wishlist
          </a>

          {/* <button className="btn btn-primary">Add to Wishlist</button>
          </div> */}
        </div>
      </div>
    </div>
    );
}

