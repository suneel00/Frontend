import React from "react";
import {
	Box,
	FooterContainer,
	Row,
	FooterLink,
} from "./FooterStyles";
 
const Footer = ({showFooter}) => {
	if(!showFooter){
		return null
	}
return (
<Box>
<FooterContainer>
<Row>

<FooterLink href="/about"><p className="font-normal">About Us</p></FooterLink>

<FooterLink href="/Contact"><p className="font-normal">Contact</p></FooterLink>

<FooterLink href="https://www.linkedin.com/in/suneel-madana-282bb3215/">
<p className="font-normal">LinkedIn</p>
</FooterLink>
<FooterLink href="https://github.com/dashboard">
<p className="font-normal">GitHub</p>
</FooterLink>
</Row>
</FooterContainer>
</Box>
	);
};
export default Footer;