import React from "react";
const Contact=()=>{
    return(
        <div>
            <h2>Get in Touch</h2>
            <h3>Email Address</h3>
            <p>Please send your message to : suneelmadana007@gmail.com</p>

        </div>
    )
}
export default Contact;