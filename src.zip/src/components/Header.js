import React from 'react';
import { Container, Nav, Navbar } from 'react-bootstrap';
import { useLocation } from 'react-router-dom';

const Header = () => {
  const location = useLocation();
  // if (location.pathname === '/home') {
  //   return null; // Don't render header on the home page
  // }
  // if (location.pathname === '/favorite') {
  //   return null; // Don't render header on the home page
  // }
  // if (location.pathname === '/searchmusic') {
  //   return null; // Don't render header on the home page
  // }
  // if (location.pathname === '/MusicDashboard') {
  //   return null; // Don't render header on the home page
  // }

  return (
    
    <Navbar bg="light" expand="lg">
      <Container>
        <Navbar.Brand img src="https://www.pngitem.com/pimgs/m/75-754403_mic-and-music-logo-hd-png-download.png" alt="Bootstrap" width="30" height="24">Grooveix</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link href="/signup">SignUp</Nav.Link>
            <Nav.Link href="/login">Login</Nav.Link>
            {/* <Nav.Link href="/home">Home</Nav.Link> */}
            <Nav.Link href="/MusicDashboard">Dashboard</Nav.Link>
            <Nav.Link href="/Wishlist">Wishlist</Nav.Link>
            <Nav.Link href="/login">Logout</Nav.Link>
            {/* Add more Nav.Link components as needed */}
            
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default Header;
