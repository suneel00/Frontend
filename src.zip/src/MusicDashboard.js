import React,{useState,useEffect} from "react";
//import axios from "axios";
import Song from "./components/Song";
import { fetchMusicApi } from "./Musicfetch";
import Footer from "./components/Footer";
//import WishlistContainer from "./Wishlist/WishlistContainer";

const MusicDashboard=()=>{

    const [songs,setSongs]=useState([]);

    const [imgurl,setImgurl]=useState("");

    const [currentPage,setCurrentPage]=useState(1);

    const [itemsPerPage]=useState(8);

    const [loading,setLoading]=useState(true);

useEffect(()=>{
    const fetchMusic =() => {
        fetchMusicApi().then((response)=>{
            console.log("In music api",response.tracks);
            // console.log(response.data.tracks.items);
            setSongs(response.tracks.items);
            setLoading(false)

        }).catch((error)=>{
            console.log("error occur in playlist",error);
        })

    };
    fetchMusic();
},[]);

const indexofLastItem=currentPage * itemsPerPage;
const indexOfFirstItem=indexofLastItem-itemsPerPage;
const currentItems=songs.slice(indexOfFirstItem,indexofLastItem);

const paginate=(pageNumber)=>setCurrentPage(pageNumber);
const nextPage=()=>{
    if(currentPage<Math.ceil(songs.length/itemsPerPage)){
        setCurrentPage(currentPage+1);
    }
};


// //wishlist
// const addToWishlist = (songName) => {
//     // Add logic to add the song to the wishlist
//     console.log(`Added to wishlist: ${songName}`);
//   };

//   // Pass addToWishlist as a prop to the Song component
//   setSongs(response.data.tracks.items.map(song => ({ ...song, addToWishlist })));

//   setLoading(false);
// };



    return(     
<div className="container"  >
    <h3 className="card-body text-center"> Welcome to Grooveix </h3>
      <div className="row">
        {!loading &&
          currentItems.map((song, id) => (
            <div key={id} className="col-md-3">
              <Song
                songName={song.track.name}
                image={song.track.album.images}
                artistName={song.track.artists[0].name}
                releaseDate={song.track.album.release_date}
                albumName={song.track.album.name}
              />
            </div>
          ))}
      </div>
      <br/>
      {songs.length > itemsPerPage && (
        <div className="pagination">
          {Array.from({
            length: Math.ceil(songs.length / itemsPerPage),
          }).map((_, index) => (
            <button key={index} onClick={() => paginate(index + 1)}>
              {index + 1}
            </button>
          ))}
          {currentPage < Math.ceil(songs.length / itemsPerPage) && (
            <button onClick={nextPage}>Next</button>
          )}
        </div>
      )}
      {/* <WishlistContainer/> */}
      <Footer showFooter={false} />
    </div>
  );
};
export default MusicDashboard;