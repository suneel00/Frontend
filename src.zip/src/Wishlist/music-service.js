import {toast} from "react-toastify";
import {myAxios} from "./helper";

export const getTrackbyId=async(trackId)=>{
    const response= await myAxios.get('/api/v1.0/musictrack/track'+trackId);
    return response.data;
}