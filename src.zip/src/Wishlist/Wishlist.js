import React, { useEffect, useState } from "react";
import { Card, Container, Row, Button } from "react-bootstrap";
import axios from "axios";
import { isLoggedIn, getCurrentUserId, getTrackbyId } from "../utils/auth";
import { toast } from "react-toastify";
import { getTrackbyId } from "./music-service";

export default function Wishlist() {
  const navigate = useNavigate();
  const [favoritelist, setFavoritelist] = useState([]);

  useEffect(() => {
    const fetchMusicApi = async () => {
      try {
        if (isLoggedIn) {
          const headers = {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          };
          const response = await axios.get(
            `http://localhost:8083/api/wishlist/getUserWishList/${getCurrentUserId()}`,
            { headers }
          );
          console.log(response);
          setFavoritelist(response.data);
        } else {
          navigate("/login");
          toast("Please login first!!!");
        }
      } catch (error) {
        console.error(error);
      }
    };

    fetchMusicApi();
  }, [navigate]);

  const removeFavorite = async (trackId) => {
    try {
      if (isLoggedIn) {
        const headers = {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        };
        const user = getCurrentUserId();

        await axios
          .delete(
            `http://localhost:8083/api/wishlist/removeTrack/${user}/${trackId}`,
            { headers }
          )
          .then((response) => {
            const updatedTracks = favoritelist.filter(
              (item) => item.id !== trackId
            );
            setFavoritelist(updatedTracks);

            console.log(response);
            toast("Deleted from wishlist");
          })
          .catch((error) => {
            toast.error("Something went wrong");
          });
      } else {
        navigate("/login");
        toast("Please login first!!!");
      }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div>
      <Container>
        <Row className="mx-2 row row-cols-sm-4">
          {favoritelist &&
            favoritelist.map((favourite, index) => (
              <Card className="mt-3" key={index}>
                <Card.Img
                  className="my-2"
                  src={getTrackbyId(favourite.id).album.images[0].url}
                  alt="Card-image"
                />
                <Card.Body>
                  <Card.Title>{favourite.name}</Card.Title>
                </Card.Body>
                <Button
                  className="m-2"
                  variant="danger"
                  onClick={() => removeFavorite(favourite.id)}
                >
                  Delete
                </Button>
              </Card>
            ))}
        </Row>
      </Container>
    </div>
  );
}


// import React from "react";

// const Wishlist = ({ wishlist, removeFromWishlist }) => {
//   return (
//     <div>
//       <h2>Wishlist</h2>
//       {wishlist.length === 0 ? (
//         <p>Your wishlist is empty.</p>
//       ) : (
//         <ul>
//           {wishlist.map((item, index) => (
//             <li key={index}>
//               {item}{" "}
//               <button onClick={() => removeFromWishlist(index)}>Delete</button>
//             </li>
//           ))}
//         </ul>
//       )}
//     </div>
//   );
// };

// export default Wishlist;

// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import { Card, Container, Row, Button } from "react-bootstrap";
// import { useNavigate } from "react-router-dom";

// import { isLoggedIn, getCurrentUserId, getTrackbyId } from "../utils/auth";
// import { toast } from "react-toastify";
// export default function Wishlist(){
//     const navigate=useNavigate();
//     const [favoritelist,setFavoritelist]=useState([]);
//     const [tracksData,setTracksData]=useState([]);

//     useEffect(()=>{
//         const fetchMusicApi=async()=>{
//             try{
//                 if(isLoggedIn){
//                     const headers = {
//                         Authorization: `Bearer ${localStorage.getItem("token")}`,
//                       };
//                       const response = await axios.get(`http://localhost:8083/api/wishlist/saveTrackToWishlist/${getCurrentUserId()}`,
//                         { headers }
//                       );
//                       console.log(response);
//                       setFavoritelist(response.data);
//                     })
//                     console.log("track:"+getTrackbyId(favoritelist[0]));
//                         // console.log("track:"+getTrackbyId(favoritelist[0]));

//                     }else{
//                         navigate("/login");
//                         toast("Please login first!!!")
//                     }
//                 }catch(error){
//                     console.error(error);
//                 }
//             };
//             fetchMusicApi();
            
//     },[]);
//     const removeFavorite=async (trackId)=>{
//         try{
//             if(isLoggedIn){
//                 const headers={
//                     Authorization:`Bearer ${localStorage.getItem("token")}`,
//                 };
//                 const user=getCurrentUserId();
//                 // console.log("track:"+JSON.stringify(getTrackbyId(trackId)));
                
//                 await axios.delete('http://localhost:8083/api/wishlist/removeTrack/'+user+'/'+trackId,{headers})
//                     .then(response=>{
//                         const updatedTracks=favoritelist.filter((item=>item.id!==trackId));
//                         setFavoritelist(updatedTracks);
                        
//                         console.log(response);
//                         toast("delete from wishlist")
//                     }).catch(error=>{
//                         toast.error("something went wrong");
//                     })
          
//             }else{
//                 navigate("/login");
//                 toast("Please login first!!!")
//             }
//         }catch(error){
//             console.error(error);
//         }
    
//     }
// return(
//         <div>
//             <Container>
//                 <Row calssName="mx-2 row row-cols-sm-4">
//                     {
//                     favoritelist && favoritelist.map((favorite,index)=>(

//                         <Card calssName="mt-3" key={index}>
//                             <Card.Img calssName='my-2' src={getTrackbyId(favorite.id).album.images[0].url} alt="Card-image"/>
//                             <Card.Body>
//                                 <Card.Title>{favourite.name}</Card.Title>
//                             </Card.Body>
//                             <Button calssName="m-2" variant="danger" onClick={()=>removeFavorite(favourite.id)}>Delete</Button>
//                         </Card>
//                     ))}
//                 </Row>
//             </Container>
//         </div>
//     )
// }