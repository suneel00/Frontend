// import React, { useState, useEffect } from "react";
// import Music from "../components/Music";
// import Header from "../components/Header";
// import Footer from "../components/Footer";
// import MusicService from "../components/services/MusicService";
 
// export default function Home () {
 
//     const [musics, setMusics] = useState(null
//     );
//     const [loading, setLoading] = useState(true);
 
//     let i = 0;
 
//     let home = true;
 
//     useEffect( () => {
//       MusicService.songsapi()
//           .then((response) => {
//             console.log(response.data.musics);
//             setMusics(response.data.musics);
//             console.log(typeof response.data.musics);
//             console.log(response.data.musics[0]);
//             setLoading(false);
//           })
//           .catch((error) => {
//             console.log(error);
//           });
//     },[])
 
//     return(
//         <>
//         <Header/>
//         <div className="home">
//             <h1>Welcome to Grooveix!</h1>
//           {!loading && (
//           <div className="music">
//           <>
//             {musics.map((music) => (
             
//              <Music
//              id=         {i++}
//              albumType=     {music.albumType}
//              artists=    {music.artists}
//              externalUrls={music.externalUrls}
//              publishedAt={music.publishedAt}
//              images=      {music.images}
//              name=        {music.name}
//              releaseDate= {music.releaseDate}
//              type=       {music.type}
//              home={home}
//            />
           
//             ))}
//             </>
//           </div>
//           )}
//         </div>
//         <Footer/>
//         </>
//     )
// }