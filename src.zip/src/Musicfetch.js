import axios from "axios";

 
let token = "" ;
let myAxios ;
const createAxios = () => {
    token =localStorage.token ;
    myAxios=axios.create({
        baseURL: "http://localhost:8089/api/v1.0/musictrack/todayTopHitsPlaylist",
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
}
 
export const fetchMusicApi = () => {
    createAxios() ;
    return myAxios
    .get()
    .then((response) => response.data);
 
};