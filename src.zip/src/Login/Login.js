import axios from "axios";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Footer from "../components/Footer";

export default function Login() {
    const navigate=useNavigate();

    const [login,setLogin]=useState({
        email:"",
        password:"",
    });

    const handleChange=(event)=>{
        const{name,value}=event.target;
        setLogin((login)=>({...login,[name]:value}));
        
    };
    const handleLogin = (event)=>{
        event.preventDefault();

        if (!login.email || !login.password) {
            alert("Please enter both email and password.");
            return;
          }
          
        axios.post("http://localhost:8083/Grooveix/login",
        {
            email:login.email,
            password:login.password,
        }).then((response)=>{
            console.log(response);
            localStorage.setItem("token",response.data.token);
            navigate("/MusicDashboard");
            alert("Login Successful");
            
        })
        .catch((error)=>{
            console.error("Login failed", error.message);
            console.log(error.response);
            alert("Login failed. Please check your credentials.");
        });
    };

    return(
        <div className="row justify-content-center pt-5">
            <div className="col-sm-6">
                <div className="card p-4">
                    <h1 className="text-center mb-3">Login </h1>
                    <div className="form-group">
                        <label>Email address:</label>
                        <input type="email" className="form-control" placeholder="email" name="email"
                            value={login.email} onChange={handleChange}/>
                    </div>
                    <div className="form-group mt-3">
                        <label>Password:</label>
                        <input type="password" className="form-control" placeholder="password" name="password"
                            value={login.password} onChange={handleChange}/>
                    </div>
                    <button type="button" onClick={handleLogin} className="btn btn-primary mt-4">Login</button>
                </div>
            </div>
            <Footer showFooter={true} />
        </div>
    );
}