import "bootstrap/dist/css/bootstrap.min.css";
import  {BrowserRouter , Route , Routes} from 'react-router-dom';
import Header from "./components/Header";
import SignUp from "./components/Signup";
import Logout from "./components/Logout";
import'./style.css';
import Footer from "./components/Footer";
import About from "./components/About";
//import Home from "./Home/Home";
import Contact from "./components/Contact";
import Landingpage from "./components/Landingpage";
import MusicDashboard from "./MusicDashboard";
import Music from "./components/Song";
import Login from "./Login/Login";
//import WishlistContainer from "./Wishlist/WishlistContainer";

function App() {
 return (
  <div>
   <BrowserRouter>
   <Header/>
  <Routes>
    <Route path="/" element={<Landingpage/>}/>
    <Route path="/login" element={<Login/>}/>
    <Route path="/signup" element={<SignUp/>} />
    {/* <Route path="/home" element={<Home/>}/> */}
    <Route path="/MusicDashboard" element={<MusicDashboard/>}/>
    <Route path="/music" element={<Music/>}/>
    <Route path="/logout" element={<Logout/>}/>
    <Route path="/about" element={<About/>}/>
    {/* <Route path="/Wishlist" element={<WishlistContainer/>}/> */}
    <Route path="/Contact" element={<Contact/>}/>
  </Routes>
  </BrowserRouter>
  <Footer/>
  </div>
 );
};
export default App;