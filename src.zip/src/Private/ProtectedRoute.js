// import React from "react"
// import { Route, Navigate, Redirect } from "react-router-dom"

// const ProtectedRoute=(({children, ...rest}) => {
//     let Authorization={'token':false}
//     return (
//         <Route {...rest} render={props => {
//             if(localStorage.getItem('token')){
//                 Authorization={'token':localStorage.getItem('token')}
//             }
//             return (
//                 <div>
//                     {Authorization.token? children : <Redirect to="/login" />}
//                 </div>
//             )
//         }}/>
//     )

// })
// export default ProtectedRoute;

import React from "react";
import { Route, Navigate, Redirect } from "react-router-dom"; // Add Redirect to the import statements

const ProtectedRoute = ({ children, ...rest }) => {
  let Authorization = { token: false };
  return (
    <Route
      {...rest}
      render={(props) => {
        if (localStorage.getItem("token")) {
          Authorization = { token: localStorage.getItem("token") };
        }
        return (
          <div>
            {Authorization.token ? (
              children
            ) : (
              <Navigate to="/login" /> // Use Navigate instead of Redirect
            )}
          </div>
        );
      }}
    />
  );
};

export default ProtectedRoute;
